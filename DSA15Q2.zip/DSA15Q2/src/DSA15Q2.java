

public class DSA15Q2 {

	// Prints smaller elements on left side of every element
	public static void printPrevSmaller(int[] arr, int n)
	{
	
		
		for (int i = 0; i < n; i++) {
			// look for smaller element on left of 'i'
			int j;
			for (j = i - 1; j >= 0; j--) {
				if (arr[j] < arr[i]) {
					System.out.print(arr[j] + ", ");
					break;
				}
			}
			// If there is no smaller element on left of 'i'
			if (j == -1)
				System.out.print(-1+", ");
		}
	}


	public static void main(String[] args)
	{
		int[] arr = { 1, 5, 0, 3, 4, 5};
		int n = arr.length;
		printPrevSmaller(arr, n);
	}
}


